﻿from turtle import *

for i in range(12):
    forward(100)
    right(150)

done()

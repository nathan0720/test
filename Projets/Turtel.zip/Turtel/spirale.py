from turtle import *

x = 0

while x < 120:
    fd(x)
    left(60)
    x += 5

done()


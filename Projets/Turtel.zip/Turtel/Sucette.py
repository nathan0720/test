from turtle import *

for i in range(6):
    fillcolor("white")
    begin_fill()
    circle(50)
    end_fill()
    left(360/12)
    fillcolor("black")
    begin_fill()
    circle(50)
    end_fill()
    left(360/12)

done()
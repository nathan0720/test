from turtle import*


c = int(input('Choisis un nombre de côtés : '))

circle(100, 360, c)

done()